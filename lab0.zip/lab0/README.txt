Camila Toro Suarez

I will be running psql on VS code on my mac. I installed psql and I'm also accessing it on isengard.

I had some problems with my password, I think I made it something I didn't know so I emailed Professor Davoll
and had it reset. I also had problems with the psql that I downloaded onto my mac, it was showing that I 
connected successfully and was showing me the csci403=> prompt but it was not doing anything, so I tried
working on the VS code terminal with isengard and I got it. 

I didn't really like that there weren't many commands that we had to try for this first intro assignment,
as someone that has never touched sql before I still feel confused after this assignment of how to travel
around the database. I would've liked for this assignment to walk you through commands of how to navigate
and things like that but it's okay.

I spent maybe 1.5 hours on this assignment but a lot of it was waiting and figuring out the password.


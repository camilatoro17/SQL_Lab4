Camila Toro Suarez

Challenges:
I had a lot of trouble getting started and moving around the database and getting the hang of how it worked. I
looked back to the lecture slides for some of the first lectures and that helped me to get started, and then 
once I knew how to navigate the database well enough I started my querys again guided by the slides. It was hard
to start, but by looking at the slides and some google searches it ended up being okay.

Like:
I actually found this assignment really fun, I was worried about not knowing where to start and not really knowing
the basics of how to do a query. It's one thing to watch it in a lecture but it's another to actually do it yourself.
I think after this lab, I have a much better understanding of actually how to do some querys and some resources
for when I get stuck. 

Time:
I spent I think 30 minutes trying to get started and get into the database, but when I was in I think it took me
about an hour to finish the querys.

Data:
I have no suggestions to add the data and I didn't find any incorrect data.